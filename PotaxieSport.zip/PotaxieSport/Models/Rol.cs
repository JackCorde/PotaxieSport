﻿namespace PotaxieSport.Models
{
    public class Rol
    {
        public int RolId { get; set; }
        public string? RolNombre { get; set; }
    }
}
