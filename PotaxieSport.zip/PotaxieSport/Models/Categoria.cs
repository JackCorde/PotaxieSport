﻿namespace PotaxieSport.Models
{
    public class Categoria
    {
        public int CategoriaId { get; set; }
        public string? CategoriaNombre { get; set; }
        public string? Rango { get; set; }
    }
}
