﻿namespace PotaxieSport.Models.ViewModels
{
    public class UsuarioLogin
    {
        public string? Correo {  get; set; }
        public string? Username { get; set; }

        public string? LaPoderosa { get; set; } = string.Empty;
    }
}
