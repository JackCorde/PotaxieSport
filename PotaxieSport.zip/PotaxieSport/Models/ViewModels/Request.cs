﻿namespace PotaxieSport.Models.ViewModels
{
    public class Request
    {
        public int EquipoId { get; set; }
        public int JugadorId { get; set; }
        public int FrecuenciaCard { get; set; }

    }
}
